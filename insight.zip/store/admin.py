from django.contrib import admin
from store.models import Events
from store.models import Category
from store.models import Registration
from store.models import Contact
from store.models import Order_event

class AdminCategory(admin.ModelAdmin):
    list_display = ['name']

class AdminOrder_event(admin.ModelAdmin):

    list_display = ['id','events','s_id','s_name','e_attendance']



# Register your models here.

admin.site.register(Events)
admin.site.register(Category,AdminCategory)
admin.site.register(Registration)
admin.site.register(Contact)
admin.site.register(Order_event , AdminOrder_event)