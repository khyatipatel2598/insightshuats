from django.db import models
import datetime
from django.conf import settings


# Create your models here.

class Category(models.Model):
    name = models.CharField(max_length=20,blank=True,default='')

    @staticmethod
    def get_all_categories():
        return Category.objects.all()

    def __str__(self):
        return self.name

class Events (models.Model) :
    event_name = models.CharField(max_length=100)
    event_price = models.IntegerField(default=0)
    Category = models.ForeignKey(Category, on_delete=models.CASCADE, default='')
    event_desc = models.CharField(max_length=200, default='')
    event_image = models.ImageField(upload_to='uplaod/products/')
    event_mail_doc = models.FileField(upload_to='uplaod/doc/',default='')

    @staticmethod
    def get_products_by_id(ids):
        return Events.objects.filter(id__in=ids)

    @staticmethod
    def get_all_events():
        return Events.objects.all()

    @staticmethod
    def get_all_Events_by_categoryid(category_id):
        print('idhr aagya mai')
        if category_id:
            # print(Events.objects.filter(category= category_id))
            return Events.objects.filter(Category=category_id)
        else:
            return Events.get_all_events()

    @staticmethod
    def get_events_by_id(ids):
        return Events.objects.filter(id=ids)


class Registration (models.Model):
    name = models.CharField(max_length= 100)
    fname = models.CharField(max_length= 100 , default='abc')
    contact_n = models.CharField( max_length=11,blank=True)
    college_id = models.CharField(max_length= 20,blank=True)
    email_id = models.EmailField(default= 'abc.123@xyz.com')
    dept = models.CharField(max_length= 100, default='abcde')
    course = models.CharField(max_length=100, default='abc')
    college_name = models.CharField(max_length=100, default='abc')
    gender = models.CharField(max_length=100, default='a')

    @staticmethod
    def get_student_by_email(email_id):
        try:
            return Registration.objects.get(email_id=email_id)
        except:
            return False

    @staticmethod
    def get_student_by_college_id(college_id):
        try:
            return Registration.objects.get(college_id=college_id)
        except:
            return False

    @staticmethod
    def get_all_students():
        return Registration.objects.all()

    @staticmethod
    def get_student_by_id(id):
        try:
            print(id, 'id as parameter')
            return Registration.objects.get(id=id)
        except:
            return False


class Contact (models.Model):
    name = models.CharField(max_length=122)
    email = models.EmailField(max_length=200)
    message = models.CharField(max_length=500)

    def __str__(self):
        return self.name

class Order_event (models.Model):
    events = models.ForeignKey(Events, on_delete=models.CASCADE)
    s_id = models.ForeignKey(Registration, on_delete=models.CASCADE)
    s_name = models.CharField(max_length=122)
    price = models.IntegerField()
    s_coordinator = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, default='1',blank=True)
    date = models.DateField(default=datetime.datetime.today)
    e_attendance = models.CharField(max_length=1, default='', blank=True)
    @staticmethod
    def get_event_by_student_id(id):
        try:
             l= Order_event.objects.filter(s_id=id)
             lo=[]
             for i in l:
                 lo.append(i.events)

             return lo


        except:
            return False

    @staticmethod
    def get_student_by_event_id(id):
        try:
            oe= Order_event.objects.filter(events=id)
            if oe:
                return oe
            else:
                s="no partcipation"
                return s


        except:
            return id

